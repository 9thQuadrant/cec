/** Automatically generated file. DO NOT MODIFY */
package com.cec.ac;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}