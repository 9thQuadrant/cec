package com.cec.ac;

import org.xwalk.core.XWalkView;

import android.app.Activity;

public class BaseActivity extends Activity {
    protected XWalkView mXWalkView;
}
