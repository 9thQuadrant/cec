package com.cec.ac;

import org.xwalk.core.XWalkView;
import com.cec.ac.R;

import android.os.Bundle;

public class MoreActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.xwview_layout);
        mXWalkView = (XWalkView) findViewById(R.id.xwalkview);
        mXWalkView.load("file://android_asset/more.html", null);
        overridePendingTransition(R.anim.push_down_in, R.anim.push_down_out);
    }
}
