package com.cec.ac;

import java.util.ArrayList;
import java.util.List;
import com.cec.ac.R;
import android.app.ListActivity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends ListActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setListAdapter(new SampleAdapter());
        
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
        case R.id.action_settings:
            Intent intent=new Intent(MainActivity.this,credits.class);
            startActivity(intent);
            return true;

        default:
            return super.onOptionsItemSelected(item);
        }
    }
    
    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onListItemClick(ListView lv, View v, int pos, long id) {
        SampleInfo info = (SampleInfo) getListAdapter().getItem(pos);
        startActivity(info.intent);
    }

    static class SampleInfo {
        String name;
        Intent intent;

        SampleInfo(String name, Intent intent) {
            this.name = name;
            this.intent = intent;
        }
    }

    class SampleAdapter extends BaseAdapter {
        private ArrayList<SampleInfo> mItems;

        public SampleAdapter() {
            Intent intent = new Intent(Intent.ACTION_MAIN, null);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            intent.setPackage(getPackageName());
            intent.addCategory(Intent.CATEGORY_SAMPLE_CODE);
            overridePendingTransition(R.anim.push_down_in, R.anim.push_down_out);
            PackageManager pm = getPackageManager();
            List<ResolveInfo> infos = pm.queryIntentActivities(intent, 0);

            mItems = new ArrayList<SampleInfo>();

            final int count = infos.size();
            for (int i = 0; i < count; i++) {
                final ResolveInfo info = infos.get(i);
                final CharSequence labelSeq = info.loadLabel(pm);
                String label = labelSeq != null ? labelSeq.toString() : info.activityInfo.name;

                Intent target = new Intent();
                target.setClassName(info.activityInfo.applicationInfo.packageName,
                        info.activityInfo.name);
                SampleInfo sample = new SampleInfo(label, target);
                
                mItems.add(sample);
            }
        }

        @Override
        public int getCount() {
            return mItems.size();
        }

        @Override
        public Object getItem(int position) {
            return mItems.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = getLayoutInflater().inflate(R.layout.lay,
                        parent, false);
            }
            TextView tv = (TextView) convertView.findViewById(R.id.tview);
            Typeface typeFace=Typeface.createFromAsset(getAssets(),"fonts/myriad.ttf");
            tv.setTypeface(typeFace);
            SampleInfo info = mItems.get(position);
            tv.setText(info.name);
            Animation fade1 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.animate);
            tv.startAnimation(fade1);
            return convertView;
        }
    }
}
